plugins { id("com.android.application") }

android { namespace = "com.yemen.numberdetector"; compileSdk = 35
    defaultConfig { applicationId = "com.yemen.numberdetector"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
