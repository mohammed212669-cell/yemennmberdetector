package com.yemen.numberdetector;
import android.telecom.Call;
import android.telecom.CallScreeningService;
public class YemenCallScreeningService extends CallScreeningService {
    @Override public void onScreenCall(Call.Details details){
        // النسخة الأولى لا تحظر المكالمات تلقائيًا؛ الهدف هو تجهيز نقطة التكامل لكشف الاسم محليًا.
        respondToCall(details, new CallResponse.Builder().setDisallowCall(false).setRejectCall(false).setSkipCallLog(false).setSkipNotification(false).build());
    }
}
