package com.yemen.numberdetector;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.PhoneNumberUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText search; TextView result; final ArrayList<String> contacts = new ArrayList<>();
    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); }
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setPadding(20,14,20,14); return t; }
    void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24); root.setGravity(Gravity.TOP); root.setLayoutDirection(ViewGroup.LAYOUT_DIRECTION_RTL);
        TextView title=tv("كاشف الأرقام اليمنية",26); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=tv("بحث محلي بدون خادم مركزي",15); sub.setGravity(Gravity.CENTER); root.addView(sub,new LinearLayout.LayoutParams(-1,-2));
        search=new EditText(this); search.setHint("أدخل الرقم اليمني"); search.setInputType(2); root.addView(search,new LinearLayout.LayoutParams(-1,-2));
        Button find=new Button(this); find.setText("بحث"); root.addView(find,new LinearLayout.LayoutParams(-1,-2));
        Button imp=new Button(this); imp.setText("استيراد جهات الاتصال محليًا"); root.addView(imp,new LinearLayout.LayoutParams(-1,-2));
        result=tv("أدخل رقمًا ثم اضغط بحث.",17); root.addView(result,new LinearLayout.LayoutParams(-1,-2));
        find.setOnClickListener(v->searchNumber(search.getText().toString()));
        imp.setOnClickListener(v->importContacts());
        setContentView(root);
    }
    String normalize(String n){ return n.replaceAll("[^0-9+]","").replaceFirst("^00967","+").replaceFirst("^967","+").replaceFirst("^0(7)","+$1"); }
    String network(String n){ String x=normalize(n).replace("+967",""); if(x.length()>0 && x.charAt(0)=='7' && x.length()>=2){ String p=x.substring(0,2); switch(p){case "70":case "71":case "72":case "73": return "يمن موبايل (تقريبي حسب المقدمة)"; case "77": return "سبأفون (تقريبي حسب المقدمة)"; case "78": return "YOU / Y (تقريبي حسب المقدمة)";} } return "لم يتم تحديد الشبكة"; }
    void searchNumber(String n){ if(n.trim().isEmpty()){result.setText("أدخل رقمًا.");return;} String norm=normalize(n); String match=""; for(String c:contacts){ if(PhoneNumberUtils.normalizeNumber(c).equals(PhoneNumberUtils.normalizeNumber(norm))){match=c;break;} } StringBuilder s=new StringBuilder("الرقم: ").append(norm).append("\nالشبكة: ").append(network(norm)); if(!match.isEmpty())s.append("\nالاسم في جهات الاتصال: ").append(match); else s.append("\nلا يوجد اسم مطابق في جهات الاتصال المحلية."); result.setText(s.toString()); }
    void importContacts(){ if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},10);return;} loadContacts(); }
    void loadContacts(){ contacts.clear(); Cursor c=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null); if(c!=null){while(c.moveToNext()) contacts.add(c.getString(1)); c.close();} result.setText("تم استيراد " + contacts.size() + " رقمًا إلى الذاكرة المحلية للتطبيق. لا يتم رفعها إلى خادم."); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==10&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)loadContacts();else result.setText("لم يتم منح إذن جهات الاتصال.");}
}
